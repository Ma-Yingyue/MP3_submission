"""Question-constrained edits and features for common scalar and relational patterns."""

import re

from sqlglot import exp

from sql_repair_rules import conjunctions, relation_terms, stem, words


COMPARATORS = {
    "at least": exp.GTE, "no fewer than": exp.GTE, "no less than": exp.GTE,
    "greater than or equal to": exp.GTE, "at most": exp.LTE, "no more than": exp.LTE,
    "less than or equal to": exp.LTE,
    "before": exp.LT, "less than": exp.LT, "fewer than": exp.LT, "below": exp.LT, "under": exp.LT,
    "after": exp.GT, "more than": exp.GT, "greater than": exp.GT, "higher than": exp.GT,
    "above": exp.GT, "over": exp.GT, "exactly": exp.EQ,
}
COMPARISON = re.compile(
    r"\b(" + "|".join(COMPARATORS) + r")\s+(-?\d+(?:\.\d+)?)\b"
)
OPERATORS = (exp.EQ, exp.GT, exp.GTE, exp.LT, exp.LTE)
REVERSED = {exp.EQ: exp.EQ, exp.GT: exp.LT, exp.GTE: exp.LTE, exp.LT: exp.GT, exp.LTE: exp.GTE}
LIST_WORDS = re.compile(r"\b(what|which|list|show|find|return|display|give)\b")
FILTER_WORDS = re.compile(
    r"\b(where|whose|with|that|who|except|but|from|before|after|more|less|above|below|"
    r"greater|higher|lower|between|in which|only|for each|per)\b"
)


def comparisons(tree, intent):
    requested = {value: COMPARATORS[phrase] for phrase, value in COMPARISON.findall(intent.question)}
    if not requested:
        return []
    found = []
    for index, comparator in enumerate(tree.find_all(*OPERATORS)):
        left, right = comparator.this, comparator.expression
        value = right if isinstance(right, exp.Literal) else None
        if value is not None and left.find(exp.Column) and value.this in requested:
            found.append((index, comparator, requested[value.this]))
        if isinstance(left, exp.Literal) and right.find(exp.Column) and left.this in requested:
            found.append((index, comparator, REVERSED[requested[left.this]]))
    return found


def comparison_edits(tree, intent):
    corrections = [(index, operator) for index, candidate, operator in comparisons(tree, intent)
                   if not isinstance(candidate, operator)]
    if not corrections:
        return
    revised = tree.copy()
    predicates = list(revised.find_all(*OPERATORS))
    for index, operator in corrections:
        predicate = predicates[index]
        predicate.replace(operator(this=predicate.this.copy(), expression=predicate.expression.copy()))
    yield revised, 1.05


def simple_projection(tree, schema, intent):
    if (not isinstance(tree, exp.Select) or not LIST_WORDS.search(intent.question)
            or intent.grouped or intent.sorted or intent.frequency or intent.ordered
            or intent.literals or intent.numbers or FILTER_WORDS.search(intent.question)):
        return
    if not (tree.args.get("joins") or tree.args.get("where")):
        return
    if any(isinstance(item, (exp.Star, exp.Subquery)) for item in tree.selects):
        return
    columns = {column.name.casefold() for item in tree.selects for column in item.find_all(exp.Column)}
    likely = []
    for name, table in schema.tables.items():
        terms = relation_terms(table["name"])
        if not terms or not terms <= intent.terms or not columns <= schema.columns[name].keys():
            continue
        likely.append((len(terms), table["name"]))
    if not likely:
        return
    likely.sort(reverse=True)
    if len(likely) > 1 and likely[0][0] == likely[1][0]:
        return
    name = likely[0][1]
    select = [item.copy() for item in tree.selects]
    for expression in select:
        for column in expression.find_all(exp.Column):
            if column.is_star:
                return
            column.set("table", None)
    relation = exp.Table(this=exp.to_identifier(name, quoted=True))
    revised = exp.select(*select).from_(relation)
    if intent.distinct and not any(item.find(exp.Distinct) for item in select):
        revised.distinct(copy=False)
    yield revised, 0.5


def remove_unused_joins(tree, schema, intent):
    if not isinstance(tree, exp.Select) or tree.args.get("with") or len(list(tree.find_all(exp.Select))) != 1:
        return
    joins = tree.args.get("joins", [])
    if not joins or any(not isinstance(join.this, exp.Table) for join in joins):
        return
    source = tree.args.get("from")
    if not source or not isinstance(source.this, exp.Table):
        return
    all_relations = [source.this, *(join.this for join in joins)]
    names = {table.alias_or_name.casefold(): table.name.casefold() for table in all_relations}
    if len(names) != len(all_relations) or not names.keys():
        return
    fields = [column for column in tree.find_all(exp.Column) if not column.find_ancestor(exp.Join)]
    if any(column.is_star for column in fields) or any(isinstance(item, exp.Star) for item in tree.selects):
        return
    possibilities = set(names)
    for field in fields:
        if field.table:
            possibilities &= {field.table.casefold()}
        else:
            possibilities &= {alias for alias, name in names.items()
                              if field.name.casefold() in schema.columns.get(name, {})}
    if len(possibilities) != 1:
        return
    alias = possibilities.pop()
    kept = next(table for table in all_relations if table.alias_or_name.casefold() == alias)
    removed = [names[table.alias_or_name.casefold()] for table in all_relations if table is not kept]
    if any(relation_terms(name) <= intent.terms for name in removed):
        return
    updated = tree.copy()
    updated.set("joins", None)
    updated.set("from", exp.From(this=kept.copy()))
    yield updated, 0.25


def deduplication_edits(tree, intent):
    if not isinstance(tree, exp.Select) or tree.args.get("distinct") or intent.count:
        return
    if not (tree.args.get("joins") and re.search(r"\b(which|what|names|list)\b", intent.question)):
        return
    if not any(isinstance(item.unalias(), exp.Column) for item in tree.selects):
        return
    yield tree.distinct(), -0.05


def between_edits(tree, intent):
    match = re.search(r"\bbetween (-?\d+(?:\.\d+)?) and (-?\d+(?:\.\d+)?)\b", intent.question)
    if not match or not isinstance(tree, exp.Select):
        return
    where = tree.args.get("where")
    if where is None:
        return
    predicates = conjunctions(where.this)
    boundaries = [item for item in predicates if isinstance(item, (exp.GT, exp.GTE, exp.LT, exp.LTE))
                  and isinstance(item.this, exp.Column) and isinstance(item.expression, exp.Literal)]
    if len(boundaries) != 2 or boundaries[0].this != boundaries[1].this:
        return
    if {item.expression.this for item in boundaries} != {match[1], match[2]}:
        return
    values = sorted((item.expression for item in boundaries), key=lambda value: float(value.this))
    revised = tree.copy()
    tests = [item.copy() for item in predicates if item not in boundaries]
    tests.append(exp.Between(this=boundaries[0].this.copy(), low=values[0].copy(), high=values[1].copy()))
    revised.set("where", exp.Where(this=exp.and_(*tests)))
    yield revised, 0.65


def semantic_edits(tree, schema, intent, feedback):
    yield from comparison_edits(tree, intent)
    yield from between_edits(tree, intent)
    if not feedback["matches_example"]:
        yield from simple_projection(tree, schema, intent)
    yield from remove_unused_joins(tree, schema, intent)
    yield from deduplication_edits(tree, intent)


def needs_schema(tree, intent, feedback):
    if tree is None or not feedback["ok"]:
        return True
    if len(feedback["columns"]) != len(intent.labels):
        return True
    if any(not isinstance(pred, comparator) for _, pred, comparator in comparisons(tree, intent)):
        return True
    if intent.distinct and not tree.find(exp.Distinct):
        return True
    if intent.ordered and not tree.args.get("order"):
        return True
    if any(re.match(r"^(sum|count|min|max|avg)\s*\(", label, re.I) for label in intent.labels):
        return not any(item.find(exp.AggFunc) for item in tree.selects)
    return False


def aggregate_label_score(tree, intent):
    if len(tree.selects) != len(intent.labels):
        return 0.0
    result = 0.0
    for label, item in zip(intent.labels, tree.selects, strict=True):
        expected = re.fullmatch(
            r"\s*(count|avg|sum|min|max|total)\s*\(\s*(distinct\s+)?([\w .*]+)\s*\)\s*",
            label, re.I)
        if not expected:
            continue
        actual = item.unalias()
        if not isinstance(actual, exp.AggFunc):
            result -= 0.65
            continue
        if actual.sql_name().casefold() != expected[1].casefold():
            result -= 0.9
            continue
        argument = actual.this
        unique = isinstance(argument, exp.Distinct)
        if unique and len(argument.expressions) == 1:
            argument = argument.expressions[0]
        expected_argument = expected[3].strip().rsplit(".", 1)[-1].casefold()
        if isinstance(argument, (exp.Column, exp.Star)) and argument.name.casefold() == expected_argument:
            result += 1.35 if unique == bool(expected[2]) else 0.15
        elif unique == bool(expected[2]):
            result += 0.3
    return result


def question_structure_score(tree, intent):
    if not isinstance(tree, exp.Select):
        return 0.0
    result = 0.0
    joins = tree.args.get("joins", [])
    group = tree.args.get("group")
    order = tree.args.get("order")
    where = tree.args.get("where")
    if re.search(r"\b(?:both|all of)\b", intent.question):
        if group and tree.args.get("having"):
            result += 0.45
        if where and any(isinstance(node, exp.Intersect) for node in where.walk()):
            result += 0.7
    if (re.search(r"\b(?:in total|overall|total number of)\b", intent.question)
            and group and not intent.grouped and not re.search(r"\bby\b", intent.question)):
        result -= 0.55
    if re.search(r"\b(?:not include|not contain|without|never|no)\b", intent.question):
        if where and any(isinstance(node.this, (exp.Exists, exp.In))
                         for node in where.find_all(exp.Not)):
            result += 0.5
    if order and re.search(r"\b(?:oldest|youngest)\b", intent.question):
        field = order.expressions[0]
        if isinstance(field.this, exp.Column) and "age" in words(field.this.name):
            result += 1.4 if bool(field.args.get("desc")) == ("oldest" in intent.question) else -0.8
    if any(join.args.get("on") is None and not join.args.get("using") for join in joins):
        result -= 0.85
    return result

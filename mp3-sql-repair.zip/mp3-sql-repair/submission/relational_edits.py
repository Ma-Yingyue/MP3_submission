"""Schema-grounded rewrites for named entities and comparisons to averages."""

import re

from sqlglot import exp

from sql_repair_rules import conjunctions, predicate_literals, relation_terms, stem, words


def named_entity_edits(tree, schema, intent):
    if (not isinstance(tree, exp.Select) or tree.args.get("group") or tree.args.get("order")
            or tree.args.get("with") or len(intent.labels) > 3 or not intent.labels):
        return
    candidates = [item.expression for item in predicate_literals(tree)]
    sources = schema.sources(tree)
    if not candidates or not sources:
        return
    labels = [name.casefold() for name in intent.labels]
    proposed = set()
    intentionally_distinct = bool(tree.args.get("distinct") and intent.distinct)
    for alias, table in sources.items():
        record = schema.tables[table]
        displays = schema.columns[table]
        if not all(label in displays for label in labels):
            continue
        options = [item["name"] for item in record["columns"] if
                   re.search(r"(?:name|title)$", item["name"], re.I) and
                   re.search(r"char|text|clob", item["type"], re.I)]
        if not options:
            continue
        entity = relation_terms(table)
        if not entity or not entity <= intent.terms:
            continue
        for literal in candidates:
            regex = r"(?<!\w)" + re.escape(literal.this.casefold().strip("%_")) + r"(?!\w)"
            if not literal.this.strip("%_") or not re.search(regex, intent.question):
                continue
            for column in options[:3]:
                key = (table, literal.this, column)
                if key in proposed:
                    continue
                proposed.add(key)
                projected = [exp.column(displays[name], quoted=True) for name in labels]
                source = exp.Table(this=exp.to_identifier(record["name"], quoted=True))
                updated = exp.select(*projected).from_(source).where(exp.EQ(
                    this=exp.column(column, quoted=True), expression=literal.copy()))
                if intentionally_distinct:
                    updated.distinct(copy=False)
                yield updated, 0.7


def average_edits(tree, schema, intent):
    if (not isinstance(tree, exp.Select) or not tree.args.get("from") or
            tree.args.get("with") or tree.args.get("joins") or tree.find(exp.Subquery)):
        return
    match = re.search(
        r"\b(older|younger|higher|lower|longer|shorter|greater|less|more) than (?:the )?average\b",
        intent.question)
    if not match:
        return
    source = tree.args["from"].this
    if not isinstance(source, exp.Table):
        return
    relation = source.name.casefold()
    if relation not in schema.tables:
        return
    identifiers = schema.tables[relation]["columns"]
    direction = exp.GT if match[1] in {"older", "higher", "longer", "greater", "more"} else exp.LT
    metric_hint = {"older": "age", "younger": "age",
                   "longer": "length", "shorter": "length"}.get(match[1])
    metrics = [item["name"] for item in identifiers if
               (metric_hint and metric_hint in words(item["name"])) or
               (not metric_hint and {stem(token) for token in words(item["name"])} <= intent.terms
                and re.search(r"real|numeric|int|double|float|decimal", item["type"], re.I)
                and not item["pk"])]
    if not metrics:
        return
    outer = source.alias_or_name
    inner = "value_source" if outer.casefold() != "value_source" else "group_source"
    group = tree.args.get("group")
    for name in metrics[:2]:
        metric = exp.column(name, table=outer, quoted=True)
        alias = exp.TableAlias(this=exp.to_identifier(inner, quoted=True))
        inner_table = exp.Table(this=exp.to_identifier(source.name, quoted=True), alias=alias)
        aggregate = exp.select(exp.Avg(this=exp.column(name, table=inner, quoted=True))).from_(inner_table)
        if intent.grouped and group:
            for key in group.expressions:
                if isinstance(key, exp.Column):
                    aggregate.where(exp.EQ(this=exp.column(key.name, table=inner, quoted=True),
                                           expression=exp.column(key.name, table=outer, quoted=True)),
                                    copy=False)
        condition = direction(this=metric, expression=exp.Subquery(this=aggregate))
        updated = tree.where(condition)
        yield updated, 0.95


def simple_group_edits(tree, intent, feedback):
    if not isinstance(tree, exp.Select):
        return
    groups = tree.args.get("group")
    aggregations = [column for column in tree.selects if column.find(exp.AggFunc)]
    if groups and not tree.args.get("having") and aggregations and not intent.grouped:
        if feedback["row_count"] > 1 and len(aggregations) == len(intent.labels):
            updated = tree.copy().select(*(column.copy() for column in aggregations), append=False)
            updated.set("group", None)
            yield updated, 0.6
    where = tree.args.get("where")
    if where and not groups and feedback["row_count"] == 0:
        terms = conjunctions(where.this)
        if len(terms) == 2 and all(isinstance(term, exp.EQ) for term in terms):
            left, right = terms
            if (isinstance(left.this, exp.Column) and left.this == right.this
                    and re.search(r"\bor\b", intent.question)):
                updated = tree.copy()
                updated.set("where", exp.Where(this=exp.or_(left.copy(), right.copy())))
                yield updated, 0.75


def relational_edits(tree, schema, intent, feedback):
    if not feedback["matches_example"] or not feedback["row_count"]:
        yield from named_entity_edits(tree, schema, intent)
    yield from compound_condition_edits(tree, intent)
    if not feedback["matches_example"] or not feedback["row_count"]:
        yield from membership_case_edits(tree, intent)
    if not feedback["matches_example"]:
        yield from average_edits(tree, schema, intent)
        yield from simple_group_edits(tree, intent, feedback)
        yield from unit_duration_edits(tree, schema, intent)
        yield from grouping_dimension_edits(tree, schema, intent)
        yield from coverage_join_edits(tree, intent, feedback)


def compound_condition_edits(tree, intent):
    if not isinstance(tree, exp.Select) or tree.args.get("with"):
        return
    where = tree.args.get("where")
    if where is None or tree.args.get("group") or tree.args.get("limit") or tree.args.get("order"):
        return
    if not re.search(r"\bboth\b", intent.question) or re.search(r"\beither\b", intent.question):
        return
    for condition in conjunctions(where.this):
        if not isinstance(condition, exp.In) or not isinstance(condition.this, exp.Column):
            continue
        literals = condition.expressions
        if len(literals) != 2 or any(not isinstance(value, exp.Literal) for value in literals):
            continue
        if any(value.this.casefold() not in intent.question for value in literals):
            continue
        alternatives = []
        for literal in literals:
            current = tree.copy()
            predicates = [term.copy() for term in conjunctions(where.this) if term is not condition]
            predicates.append(exp.EQ(this=condition.this.copy(), expression=literal.copy()))
            current.set("where", exp.Where(this=exp.and_(*predicates)))
            alternatives.append(current)
        yield exp.Intersect(this=alternatives[0], expression=alternatives[1], distinct=True), 0.9



def name_filter_alignment(tree, schema, intent):
    if not isinstance(tree, exp.Select):
        return 0.0
    sources = {alias.casefold(): table for alias, table in schema.sources(tree).items()}
    if not sources:
        return 0.0
    confidence = 0.0
    for predicate in predicate_literals(tree):
        if not isinstance(predicate, exp.EQ) or predicate.find_ancestor(exp.Select) is not tree:
            continue
        literal = predicate.expression.this.casefold()
        column = predicate.this
        if len(literal) < 2 or literal not in intent.question:
            continue
        for alias, table in sources.items():
            if column.table and column.table.casefold() != alias:
                continue
            table_name = " ".join(re.findall(r"[a-z0-9]+", table.casefold()))
            field = column.name.casefold()
            if field not in schema.columns[table] or not re.search(r"(name|title)$", field):
                continue
            if re.search(r"\b" + re.escape(table_name) + r'\s+(?:named\s+)?["\']?' +
                         re.escape(literal) + r"(?!\w)", intent.question):
                confidence = max(confidence, 3.0)
    return confidence


def alphabetic_order_score(tree, schema, intent):
    order = tree.args.get("order")
    if not order or "alphabetic" not in intent.question or not isinstance(tree, exp.Select):
        return 0.0
    first = order.expressions[0].this
    if not isinstance(first, exp.Column):
        return 0.0
    sources = schema.sources(tree)
    types = [column["type"] for alias, table in sources.items()
             if not first.table or alias.casefold() == first.table.casefold()
             for column in schema.tables[table]["columns"]
             if column["name"].casefold() == first.name.casefold()]
    if len(types) != 1:
        return 0.0
    return 1.3 if re.search(r"text|char|clob", types[0], re.I) else -1.1


def bridge_joins(tree, schema):
    if not isinstance(tree, exp.Select) or tree.args.get("with"):
        return
    joins = tree.args.get("joins", [])
    sources = {alias.casefold(): (alias, table) for alias, table in schema.sources(tree).items()}
    for index, join in enumerate(joins):
        on = join.args.get("on")
        if not isinstance(join.this, exp.Table) or not isinstance(on, exp.EQ):
            continue
        if join.side not in ("", "LEFT") or join.kind:
            continue
        left, right = on.this, on.expression
        if not isinstance(left, exp.Column) or not isinstance(right, exp.Column):
            continue
        alias = join.this.alias_or_name.casefold()
        if left.table.casefold() == alias:
            left, right = right, left
        if (right.table.casefold() != alias or left.table.casefold() not in sources
                or alias not in sources or left.table.casefold() == alias):
            continue
        if left.name.casefold() == right.name.casefold():
            continue
        lhs, left_table = sources[left.table.casefold()]
        rhs, right_table = sources[alias]
        if list(schema.links(left_table, right_table)):
            continue
        excluded = {table for _, table in sources.values()}
        for path in schema.paths(left_table, right_table, excluded):
            if len(path) != 2:
                continue
            (bridge, first_left, first_right), (_, second_left, second_right) = path
            name = schema.tables[bridge]["name"]
            if name.casefold() in sources:
                continue
            new_relation = exp.Table(this=exp.to_identifier(name, quoted=True))
            first = exp.Join(this=new_relation, side=join.args.get("side"), on=exp.EQ(
                this=exp.column(first_left, table=lhs, quoted=True),
                expression=exp.column(first_right, table=name, quoted=True)))
            updated = tree.copy()
            copied = updated.args["joins"]
            copied[index].set("on", exp.EQ(
                this=exp.column(second_left, table=name, quoted=True),
                expression=exp.column(second_right, table=rhs, quoted=True)))
            updated.set("joins", [*copied[:index], first, *copied[index:]])
            yield updated, 0.7


def duplicate_join_edits(tree):
    if not isinstance(tree, exp.Select):
        return
    joins = tree.args.get("joins", [])
    seen = set()
    duplicate = set()
    for index, join in enumerate(joins):
        if not isinstance(join.this, exp.Table):
            continue
        key = (join.this.alias_or_name.casefold(), join.this.name.casefold(),
               join.sql(dialect="sqlite", comments=False))
        if key in seen:
            duplicate.add(index)
        seen.add(key)
    if duplicate:
        revised = tree.copy()
        revised.set("joins", [item for index, item in enumerate(revised.args["joins"])
                              if index not in duplicate])
        yield revised, 0.7



def unit_duration_edits(tree, schema, intent):
    if not isinstance(tree, exp.Select):
        return
    match = re.search(r"\b(\d{1,2})[ -]+minutes?\b", intent.question)
    if not match:
        return
    sources = schema.sources(tree)
    for index, comparison in enumerate(tree.find_all(exp.EQ)):
        column, literal = comparison.this, comparison.expression
        if not isinstance(column, exp.Column) or not isinstance(literal, exp.Literal):
            continue
        if not {"duration", "length", "time"} & words(column.name) or literal.this != match[1]:
            continue
        available = [record["type"] for alias, table in sources.items()
                     if not column.table or alias.casefold() == column.table.casefold()
                     for record in schema.tables[table]["columns"]
                     if record["name"].casefold() == column.name.casefold()]
        if len(available) != 1 or not re.search(r"text|char|clob", available[0], re.I):
            continue
        for text in (f"{match[1]}:00", f"{match[1]}:%"):
            revised = tree.copy()
            predicate = list(revised.find_all(exp.EQ))[index]
            operator = exp.Like if "%" in text else exp.EQ
            predicate.replace(operator(this=predicate.this.copy(), expression=exp.Literal.string(text)))
            yield revised, 0.6


def grouping_dimension_edits(tree, schema, intent):
    if not isinstance(tree, exp.Select) or not tree.args.get("group") or not tree.args.get("having"):
        return
    each = re.search(r"\b(?:for each|per|for every) ([a-z][a-z0-9_]*)", intent.question)
    if not each:
        return
    term = stem(each[1])
    for alias, table in schema.sources(tree).items():
        group = tree.args["group"]
        present = {column.name.casefold() for column in group.find_all(exp.Column)}
        options = [column for column in schema.columns[table].values()
                   if column.casefold() not in present and {"id", term} <= {stem(x) for x in words(column)}]
        if len(options) == 1:
            yield tree.group_by(exp.column(options[0], table=alias, quoted=True)), 0.65



def membership_case_edits(tree, intent):
    for index, predicate in enumerate(tree.find_all(exp.In)):
        if not isinstance(predicate.this, exp.Column) or not predicate.expressions:
            continue
        if any(not isinstance(item, exp.Literal) or not item.is_string or len(item.this) < 2
               or item.this.casefold() not in intent.question or item.this.casefold() in intent.literals
               for item in predicate.expressions):
            continue
        updated = tree.copy()
        membership = list(updated.find_all(exp.In))[index]
        membership.set("this", exp.Collate(this=membership.this.copy(), expression=exp.var("NOCASE")))
        yield updated, 0.45


def coverage_join_edits(tree, intent, feedback):
    if (not isinstance(tree, exp.Select) or not tree.args.get("group")
            or not (intent.grouped or re.search(r"\ball\b", intent.question))):
        return
    for index, join in enumerate(tree.args.get("joins", [])):
        if join.side or join.kind or not join.args.get("on"):
            continue
        revised = tree.copy()
        revised.args["joins"][index].set("side", "LEFT")
        yield revised, 0.35

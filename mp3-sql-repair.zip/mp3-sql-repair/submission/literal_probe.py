"""One bounded public SQL probe to ground a textual literal in a schema column."""

from dataclasses import dataclass
import re

from sqlglot import exp

from sql_repair_rules import predicate_literals


@dataclass(frozen=True)
class Probe:
    candidate: object
    predicate_index: int
    literal: str
    sql: str

    def proposals(self, feedback, intent):
        if not feedback["ok"]:
            return
        for row in feedback["rows"]:
            value = row[0]
            if not isinstance(value, str) or value == self.literal or len(value) > 120:
                continue
            token = value.casefold().strip()
            original = self.literal.casefold()
            if token != original and token not in intent.question:
                if not re.search(r"(?<!\w)" + re.escape(original) + r"(?!\w)", token):
                    continue
            tree = self.candidate.tree.copy()
            predicate = list(predicate_literals(tree))[self.predicate_index]
            predicate.set("expression", exp.Literal.string(value))
            yield tree.sql(dialect="sqlite", comments=False)


def plan_probe(candidate, schema, intent):
    tree = candidate.tree
    if not isinstance(tree, exp.Select):
        return None
    sources = schema.sources(tree)
    predicates = list(predicate_literals(tree))
    for index, predicate in enumerate(predicates):
        column, literal = predicate.this, predicate.expression
        if not isinstance(predicate, exp.EQ) or predicate.find_ancestor(exp.Select) is not tree:
            continue
        if not (2 <= len(literal.this) <= 80 and literal.this.casefold() in intent.question):
            continue
        if not re.search(r"[a-zA-Z]", literal.this):
            continue
        matches = [(table, item["name"]) for alias, table in sources.items()
                   if not column.table or alias.casefold() == column.table.casefold()
                   for item in schema.tables[table]["columns"]
                   if item["name"].casefold() == column.name.casefold()
                   and re.search(r"CHAR|TEXT|CLOB", item["type"], re.I)]
        if len(matches) != 1:
            continue
        table, name = matches[0]
        field = exp.column(name, quoted=True)
        relation = exp.Table(this=exp.to_identifier(schema.tables[table]["name"], quoted=True))
        contained = exp.GT(
            this=exp.func("INSTR", exp.Lower(this=field.copy()), exp.Literal.string(literal.this.casefold())),
            expression=exp.Literal.number(0))
        query = exp.select(field).distinct().from_(relation).where(contained).order_by(field.copy()).limit(8)
        return Probe(candidate, index, literal.this, query.sql(dialect="sqlite"))
    return None

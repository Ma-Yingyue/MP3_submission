"""Reconstruct requested projections and their schema-grounded join paths."""

from collections import Counter
from itertools import permutations
import re

from sqlglot import exp

from sql_repair_rules import expected_projection, relation_terms


LABEL = re.compile(r"\s*(?:\w+\.)?([a-z_]\w*)\s*", re.I)
AGGREGATE_LABEL = re.compile(r"\s*(?:avg|sum|min|max|total|count)\s*\(\s*(?:distinct\s+)?([^()]+)\s*\)\s*", re.I)


def projected_columns(labels):
    for label in labels:
        aggregate = AGGREGATE_LABEL.fullmatch(label)
        match = LABEL.fullmatch(aggregate[1] if aggregate else label)
        if match:
            yield match[1].casefold()


def link_projection(tree, schema, intent):
    if not isinstance(tree, exp.Select) or tree.args.get("with") or tree.args.get("distinct"):
        return
    sources = schema.sources(tree)
    if not sources:
        return
    wanted = set(projected_columns(intent.labels))
    existing = set().union(*(schema.columns[name] for name in sources.values()))
    missing = wanted - existing
    if not missing or len(missing) > 3:
        return
    present_tables = set(sources.values())
    table_matches = []
    for name, available in schema.columns.items():
        if not missing <= available.keys() or name in present_tables:
            continue
        name_terms = relation_terms(name)
        score = len(name_terms & intent.terms) / max(1, len(name_terms))
        table_matches.append((score, name))
    for similarity, target in sorted(table_matches, key=lambda x: (-x[0], x[1]))[:3]:
        paths = [(alias, path) for alias, source in sources.items()
                 for path in schema.paths(source, target, present_tables)]
        for alias, path in sorted(paths, key=lambda item: len(item[1]))[:2]:
            updated = tree.copy()
            current = alias
            for related, left, right in path:
                table = schema.tables[related]["name"]
                if table.casefold() in {alias.casefold() for alias in sources}:
                    break
                relation = exp.Table(this=exp.to_identifier(table, quoted=True))
                condition = exp.EQ(this=exp.column(left, table=current, quoted=True),
                                   expression=exp.column(right, table=table, quoted=True))
                updated.join(relation, on=condition, copy=False)
                current = table
            else:
                revised = expected_projection(updated, schema, intent.labels)
                if revised is not None:
                    yield revised, 0.55 + 0.35 * similarity


def group_sort_edits(tree, schema, intent):
    if not isinstance(tree, exp.Select):
        return
    target = re.search(r"\b(?:ordered?|sorted?) by ([^,;?.]+)", intent.question)
    order = tree.args.get("order")
    if not target or (not intent.ordered and not intent.sorted):
        return
    terms = relation_terms(target[1]) - {"ascending", "descending", "order", "the"}
    if not terms:
        return
    choices = []
    for alias, table in schema.sources(tree).items():
        for name in schema.columns[table].values():
            field = relation_terms(name)
            shared = field & terms
            if not shared:
                continue
            score = len(shared) / max(1, len(field))
            choices.append((score, alias, name))
    desc = intent.descending and not intent.ascending
    for score, alias, name in sorted(choices, key=lambda x: (-x[0], x[1], x[2]))[:2]:
        if order and len(order.expressions) > 1:
            continue
        column = exp.column(name, table=alias, quoted=True)
        new_order = exp.Ordered(this=column, desc=desc, nulls_first=not desc)
        yield tree.order_by(new_order, append=False), 0.4 + 0.35 * score


def result_column_edits(tree, intent, feedback, example):
    if (not isinstance(tree, exp.Select) or not feedback["ok"] or feedback["matches_example"]
            or not feedback["rows"] or not example["rows"]
            or len(tree.selects) != len(intent.labels) or len(intent.labels) > 5):
        return
    if feedback["row_count"] != example["row_count"] or len(feedback["columns"]) != len(intent.labels):
        return
    expected = Counter(map(tuple, example["rows"]))
    actual = feedback["rows"]
    if len(expected) == 0 or len(actual) != len(example["rows"]):
        return
    identity = tuple(range(len(intent.labels)))
    if not feedback["truncated"] and not example["truncated"]:
        for mapping in permutations(identity):
            if mapping == identity:
                continue
            if Counter(tuple(row[index] for index in mapping) for row in actual) != expected:
                continue
            revised = tree.copy().select(*(tree.selects[index].copy() for index in mapping), append=False)
            yield revised, 1.0
            break
    if intent.ordered and not tree.args.get("order") and Counter(map(tuple, actual)) == expected:
        count = len(expected)
        if count < 2:
            return
        for index, expression in enumerate(tree.selects):
            if not isinstance(expression.unalias(), exp.Column):
                continue
            column_values = [row[index] for row in example["rows"]]
            if any(value is None for value in column_values):
                continue
            for descending in (False, True):
                try:
                    sorted_values = sorted(column_values, reverse=descending)
                except TypeError:
                    continue
                if column_values == sorted_values and len(set(column_values)) > 1:
                    order = exp.Ordered(this=expression.unalias().copy(), desc=descending,
                                        nulls_first=not descending)
                    yield tree.order_by(order), 0.45


def projection_owner_edits(tree, schema, intent):
    if not isinstance(tree, exp.Select) or not tree.args.get("joins") or not intent.labels:
        return
    if not all(LABEL.fullmatch(label) for label in intent.labels):
        return
    names = [LABEL.fullmatch(label)[1].casefold() for label in intent.labels]
    sources = schema.sources(tree)
    if any(not isinstance(value.unalias(), exp.Column) for value in tree.selects):
        return
    matching = []
    for alias, relation in sources.items():
        terms = relation_terms(relation)
        columns = schema.columns[relation]
        if terms and terms <= intent.terms and set(names) <= columns.keys():
            matching.append((len(terms), alias, columns))
    matching.sort(key=lambda item: (-item[0], item[1]))
    if not matching or len(matching) > 1 and matching[0][0] == matching[1][0]:
        return
    _, alias, columns = matching[0]
    if all(part.unalias().table.casefold() == alias.casefold() for part in tree.selects):
        return
    if any(tree.args.get(key) for key in ("group", "having", "order")):
        return
    projected = [exp.column(columns[name], table=alias, quoted=True) for name in names]
    yield tree.copy().select(*projected, append=False), 0.7

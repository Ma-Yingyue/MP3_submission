"""SQL parsing, semantic evidence and local rewrites for the SQLite repair policy."""

from collections import Counter
from dataclasses import dataclass
from difflib import SequenceMatcher
import re

import sqlglot
from sqlglot import exp
from sqlglot.errors import OptimizeError, TokenError
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.scope import traverse_scope

from mp3_sql.sqlite_tool import validate_sql


def parse(sql):
    try:
        return validate_sql(sql)
    except ValueError:
        return None


def sql_key(tree):
    canonical = normalize_identifiers(tree.copy(), dialect="sqlite")
    if isinstance(canonical, exp.Select) and not canonical.args.get("with"):
        relations = list(canonical.find_all(exp.Table))
        if all(table.find_ancestor(exp.Select) is canonical for table in relations):
            aliases = {table.alias_or_name: f"t{index}" for index, table in enumerate(relations, 1)}
            if len(aliases) == len(relations) and all(table.name for table in relations):
                for table in relations:
                    table.set("alias", exp.TableAlias(this=exp.to_identifier(aliases[table.alias_or_name])))
                for column in canonical.find_all(exp.Column):
                    if column.table in aliases:
                        column.set("table", exp.to_identifier(aliases[column.table]))
                        if isinstance(column.this, exp.Identifier) and re.fullmatch(r"[a-z_][a-z0-9_]*", column.name):
                            column.this.set("quoted", False)
    return canonical.sql(dialect="sqlite", comments=False)


def words(text):
    return set(re.findall(r"[a-z0-9]+", text.casefold()))


def stem(word):
    if len(word) > 4 and word.endswith("ies"):
        return word[:-3] + "y"
    if len(word) > 3 and word.endswith("s") and not word.endswith(("ss", "us")):
        return word[:-1]
    return word


def relation_terms(name):
    return {stem(word) for word in words(name)} - {"a", "an", "and", "of", "or", "the", "to"}


def name_key(text):
    return re.sub(r"[^a-z0-9]", "", text.casefold())


def label_match(query_labels, expected_labels):
    if len(query_labels) != len(expected_labels) or not expected_labels:
        return 0.0
    return sum(name_key(actual) == name_key(expected)
               for actual, expected in zip(query_labels, expected_labels)) / len(expected_labels)


@dataclass(frozen=True)
class Intent:
    question: str
    raw_question: str
    ordered: bool
    labels: tuple
    count: bool
    distinct: bool
    grouped: bool
    sorted: bool
    frequency: bool
    descending: bool
    ascending: bool
    numbers: frozenset
    terms: frozenset
    literals: frozenset

    @classmethod
    def read(cls, observation):
        raw_question = observation["task"]["question"][:4000]
        question = raw_question.casefold()
        count = bool(re.search(r"\b(how many|number of|count|total number)\b", question))
        distinct = bool(re.search(r"\b(distinct|unique|different)\b", question))
        grouped = bool(re.search(r"\b(each|for every|per)\b", question))
        sorted_ = bool(re.search(r"\b(order(?:ed)? by|sort(?:ed)? by|ascending|descending|alphabetic(?:al(?:ly)?)?)\b", question))
        frequency = bool(re.search(r"\b(most|least) (common|frequent|often|popular)\b", question))
        descending = bool(re.search(r"\b(descending|highest|largest|greatest|latest|most|longest|youngest|maximum|top)\b", question))
        ascending = bool(re.search(r"\b(ascending|lowest|smallest|fewest|earliest|least|shortest|oldest|minimum|alphabetic(?:al(?:ly)?)?|bottom)\b", question))
        numbers = frozenset(re.findall(r"(?<![\w.])-?\d+(?:\.\d+)?(?![\w.])", question))
        terms = frozenset(stem(word) for word in words(question))
        literals = frozenset(double or single for double, single in re.findall(
            r'''"([^"]+)"|(?<!\w)'([^']+)'(?!\w)''', question))
        return cls(question, raw_question, observation["ordered"], tuple(observation["example"]["columns"]),
                   count, distinct, grouped, sorted_, frequency, descending, ascending,
                   numbers, terms, literals)

    def score(self, tree):
        expressions = tree.selects
        select = tree
        while isinstance(select, exp.SetOperation):
            select = select.left
        if not isinstance(select, exp.Select):
            return 0.0
        aggregates = tuple(node for expression in expressions
                           for node in expression.find_all(exp.AggFunc))
        has_count = any(isinstance(node, exp.Count) for node in aggregates)
        distinct = bool(select.args.get("distinct") or any(
            isinstance(node.this, exp.Distinct) for node in aggregates))
        group = select.args.get("group")
        order = tree.args.get("order")
        limit = tree.args.get("limit")
        expected_count = any(re.match(r"^count\s*\(", label, re.I) for label in self.labels)
        value = 1.9 * label_match([item.output_name or item.sql(dialect="sqlite")
                                  for item in expressions], self.labels)
        if self.count or expected_count:
            value += 1.2 if has_count else -1.3
        elif has_count:
            value -= 0.55
        if self.distinct:
            value += 1.8 if distinct else -0.6
        elif distinct:
            value -= 1.30
        if self.frequency:
            value += 1.75 if group and order and order.find(exp.Count) else -0.7
        elif self.grouped and (self.count or aggregates):
            value += 1.15 if group else -0.8
        if self.sorted or self.ordered:
            value += 1.35 if order else -0.8
        elif order and not limit:
            value -= 0.35
        if order and self.descending != self.ascending:
            first = order.expressions[0]
            if isinstance(first, exp.Ordered):
                value += 0.8 if bool(first.args.get("desc")) == self.descending else -0.45
        if limit and not (self.sorted or self.ordered or self.descending or self.ascending
                          or re.search(r"\b(first|last|one|any)\b", self.question)):
            value -= 0.95
        cols = {stem(word) for col in tree.find_all(exp.Column) for word in words(col.name)}
        value += 0.17 * min(8, len(cols & self.terms))
        literals = {literal.this.casefold() for literal in tree.find_all(exp.Literal)
                    if literal.is_string}
        value += 0.8 * len(self.literals & literals)
        for literal in literals - self.literals:
            if literal.strip("%_") and literal.strip("%_") in self.question:
                value += 0.25
        numbers = {literal.this for literal in tree.find_all(exp.Literal) if not literal.is_string}
        value += 0.25 * len(self.numbers & numbers)
        expects_aggregate = any(re.match(r"^(sum|avg|min|max|total)\s*\(", label, re.I)
                                for label in self.labels)
        if expects_aggregate:
            value += 1.3 if aggregates else -0.65
        negated = bool(re.search(r"\b(never|do not have|does not have|without|not have)\b", self.question))
        if negated:
            anti = any(isinstance(node.this, (exp.In, exp.Exists)) for node in tree.find_all(exp.Not))
            value += 1.75 if anti else 0.0
        tables = {stem(word) for table in tree.find_all(exp.Table) for word in words(table.name)}
        value += 0.3 * min(5, len(tables & self.terms))
        if order and limit and re.search(r"\b(first|earliest)\b", self.question):
            value += 0.7 if not order.expressions[0].args.get("desc") else -0.6
        value -= 0.25 * len(list(tree.find_all(exp.Join)))
        value -= 0.2 * max(0, len(list(tree.find_all(exp.Select))) - 1)
        return value


class Schema:
    def __init__(self, tables):
        self.tables = {table["name"].casefold(): table for table in tables}
        self.columns = {
            key: {column["name"].casefold(): column["name"] for column in table["columns"]}
            for key, table in self.tables.items()
        }

    def sources(self, select):
        source = select.args.get("from")
        relations = [source.this] if source else []
        relations.extend(join.this for join in select.args.get("joins", []))
        return {table.alias_or_name: table.name.casefold() for table in relations
                if isinstance(table, exp.Table) and table.name.casefold() in self.tables}

    def links(self, left, right):
        for source, target, swapped in ((left, right, False), (right, left, True)):
            for key in self.tables[source].get("foreign_keys", []):
                if key["table"].casefold() == target and key["from"] and key["to"]:
                    pair = (key["from"], key["to"])
                    yield pair[::-1] if swapped else pair

    def paths(self, start, finish, excluded):
        direct = list(self.links(start, finish))
        if direct:
            for columns in direct:
                yield [(finish, *columns)]
            return
        for middle in self.tables:
            if middle == start or middle == finish or middle in excluded:
                continue
            for left, right in self.links(start, middle):
                for other_left, other_right in self.links(middle, finish):
                    yield [(middle, left, right), (finish, other_left, other_right)]

    def join_missing_column(self, select, column, sources):
        if not sources or select.args.get("with"):
            return
        for target, columns in self.columns.items():
            if column.name.casefold() not in columns or target in sources.values():
                continue
            if column.table and column.table.casefold() != target:
                continue
            for alias, source in sources.items():
                for path in self.paths(source, target, set(sources.values())):
                    updated = select.copy()
                    prior_alias = alias
                    for relation, lhs, rhs in path:
                        table = self.tables[relation]["name"]
                        if table.casefold() in {name.casefold() for name in sources}:
                            break
                        on = exp.EQ(this=exp.column(lhs, table=prior_alias, quoted=True),
                                    expression=exp.column(rhs, table=table, quoted=True))
                        join_table = exp.Table(this=exp.to_identifier(table, quoted=True))
                        updated.join(join_table, on=on, copy=False)
                        prior_alias = table
                    else:
                        for occurrence in updated.find_all(exp.Column):
                            if occurrence == column and occurrence.find_ancestor(exp.Select) is updated:
                                occurrence.replace(exp.column(columns[column.name.casefold()],
                                                              table=prior_alias, quoted=True))
                        yield updated, "foreign-key join", 0.6 - 0.2 * (len(path) - 1)


def sqlite_message(feedback):
    error = feedback.get("error") or {}
    return re.sub(r"\x1b\[[0-9;]*m", "", error.get("message", ""))


def syntax_edits(sql, feedback):
    message = sqlite_message(feedback).casefold()
    if "parse error" not in message and "syntax error" not in message:
        return
    stripped = re.sub(r"^\s*```(?:sql)?\s*|\s*```\s*$", "", sql, flags=re.I)
    cleaned = re.sub(r",\s*(?=FROM\b)", " ", stripped, flags=re.I)
    if cleaned != sql:
        yield cleaned, "syntax cleanup", 0.3
    # Tokenization preserves literal boundaries while finding unmatched parentheses.
    try:
        tokens = sqlglot.tokenize(cleaned, read="sqlite")
    except TokenError:
        return
    balance = Counter(token.token_type.name for token in tokens)
    missing = balance["L_PAREN"] - balance["R_PAREN"]
    if 0 < missing <= 3:
        yield cleaned.rstrip().rstrip(";") + ")" * missing, "close parentheses", 0.4


def identifier_edits(tree, schema, feedback):
    message = sqlite_message(feedback)
    missing = re.search(r"(no such|ambiguous) column(?: name)?:\s*([^\n]+)", message, re.I)
    table_error = re.search(r"no such table:\s*([^\n]+)", message, re.I)
    if table_error:
        target = table_error[1].strip().casefold()
        for table in tree.find_all(exp.Table):
            if table.name.casefold() != target:
                continue
            options = sorted(schema.tables, key=lambda name: (-similarity(target, name), name))
            for name in options[:2]:
                if similarity(target, name) >= 0.68:
                    updated = tree.copy()
                    for occurrence in updated.find_all(exp.Table):
                        if occurrence.name.casefold() == target:
                            occurrence.set("this", exp.to_identifier(schema.tables[name]["name"], quoted=True))
                    yield updated, "table name correction", 0.6
    if not missing:
        return
    target = missing[2].strip().casefold()
    for scope_index, select in enumerate(tree.find_all(exp.Select)):
        sources = schema.sources(select)
        local = [col for col in select.find_all(exp.Column)
                 if col.find_ancestor(exp.Select) is select and
                 target in {col.name.casefold(), f"{col.table}.{col.name}".casefold()}]
        if not local:
            continue
        column = local[0]
        candidates = []
        for alias, table in sources.items():
            for name, spelling in schema.columns[table].items():
                score = similarity(column.name.casefold(), name)
                if score >= 0.62:
                    candidates.append((score + 0.06 * (alias.casefold() == column.table.casefold()),
                                       alias, spelling))
        for score, alias, spelling in sorted(candidates, reverse=True)[:3]:
            updated = tree.copy()
            scope = list(updated.find_all(exp.Select))[scope_index]
            for occurrence in scope.find_all(exp.Column):
                if occurrence == column and occurrence.find_ancestor(exp.Select) is scope:
                    occurrence.replace(exp.column(spelling, table=alias, quoted=True))
            yield updated, "column name or qualifier correction", 0.55 * score
        if tree is select and missing[1].casefold() == "no such":
            yield from schema.join_missing_column(select, column, sources)


def similarity(left, right):
    return SequenceMatcher(None, name_key(left), name_key(right)).ratio()


def unqualified_sql(expression):
    copied = expression.copy()
    for column in copied.find_all(exp.Column):
        column.set("table", None)
    return copied.sql(dialect="sqlite")


def expected_projection(tree, schema, labels):
    if not labels or len(labels) > 10:
        return None
    sources = schema.sources(tree)
    expressions = tree.selects
    replacements = []
    for label in labels:
        existing = [item for item in expressions
                    if name_key(item.output_name or item.sql(dialect="sqlite")) == name_key(label)]
        if not existing and "(" in label:
            normalized = re.sub(r"[a-z_][a-z_0-9]*\.", "", label.casefold())
            existing = [item.unalias() for item in expressions if
                        name_key(unqualified_sql(item.unalias())) == name_key(normalized)]
        if existing:
            replacements.append(existing[0].copy())
            continue
        aggregate = re.fullmatch(r'(count|sum|avg|min|max|total)\s*\(\s*(?:(distinct)\s+)?([\w .*`\[\]"]+)\s*\)', label, re.I)
        token = (aggregate[3] if aggregate else label).strip().strip('`[]"')
        if token == "*" and aggregate and not aggregate[2]:
            item = exp.Star()
        else:
            if not re.fullmatch(r"[\w ]+(?:\.[\w ]+)?", token):
                return None
            qualifier, _, name = token.rpartition(".")
            matches = [(alias, columns[token_name])
                       for alias, table in sources.items()
                       if not qualifier or qualifier.casefold() in {alias.casefold(), table}
                       for columns in (schema.columns[table],)
                       for token_name in (name.casefold(),) if token_name in columns]
            if not matches and qualifier and aggregate:
                matches = [(alias, schema.columns[table][name.casefold()])
                           for alias, table in sources.items()
                           if name.casefold() in schema.columns[table]]
            if len(matches) != 1:
                return None
            alias, spelling = matches[0]
            item = exp.column(spelling, table=alias, quoted=True)
        if aggregate:
            if aggregate[2]:
                item = exp.Distinct(expressions=[item])
            function = aggregate[1].upper()
            item = exp.func(function, item)
        replacements.append(item)
    updated = tree.copy().select(*replacements, append=False)
    aliases = {item.alias.casefold(): item.this for item in expressions if item.alias}
    retained = {item.alias.casefold() for item in replacements if item.alias}
    for clause in ("order", "group", "having"):
        node = updated.args.get(clause)
        if node is None:
            continue
        for column in node.find_all(exp.Column):
            alias = column.name.casefold()
            if not column.table and alias in aliases and alias not in retained:
                column.replace(aliases[alias].copy())
    return updated


def result_edits(tree, schema, intent, feedback, example):
    if not isinstance(tree, exp.Select):
        return
    matches = feedback.get("matches_example", False)
    observed_count = feedback["row_count"]
    target_count = example["row_count"]
    has_distinct = bool(tree.args.get("distinct"))
    expressions = tree.selects
    if ((intent.distinct and not has_distinct) or
        (has_distinct and not intent.distinct and (matches or observed_count < target_count)) or
        (not has_distinct and not matches and observed_count > target_count)):
        yield tree.distinct(distinct=not has_distinct), "adjust DISTINCT", 0.4
    if label_match(feedback["columns"], intent.labels) < 1:
        revised = expected_projection(tree, schema, intent.labels)
        if revised is not None:
            yield revised, "align projection to schema and public column labels", 0.6

    order = tree.args.get("order")
    if order and (intent.ordered or tree.args.get("limit")) and (
        not matches or intent.descending != intent.ascending
    ):
        first = order.expressions[0]
        if isinstance(first, exp.Ordered):
            updated = tree.copy()
            element = updated.args["order"].expressions[0]
            desc = not bool(first.args.get("desc"))
            element.set("desc", desc)
            element.set("nulls_first", not desc)
            yield updated, "reverse ordering direction", 0.35
    if not order and intent.sorted:
        available = [item for item in expressions if isinstance(item, exp.Column)]
        if len(available) == 1:
            ordered = exp.Ordered(this=available[0].copy(), desc=intent.descending,
                                  nulls_first=not intent.descending)
            yield tree.order_by(ordered), "add requested ordering", 0.15

    if not matches:
        yield from question_literal_edits(tree, intent)
        yield from single_table_edits(schema, intent)
    if not matches or not observed_count:
        yield from broadening_edits(tree, intent)
    if intent.ordered and order and (not matches or "alphabetic" in intent.question):
        yield from order_through_foreign_key(tree, schema, intent)
    yield from anti_join_edits(tree, intent)
    yield from prune_joins(tree, schema, intent)
    yield from foreign_key_edits(tree, schema)

    group = tree.args.get("group")
    if intent.grouped and not group and any(item.find(exp.AggFunc) for item in expressions):
        keys = [item.unalias().copy() for item in expressions if isinstance(item.unalias(), exp.Column)]
        if keys:
            yield tree.group_by(*keys), "group selected dimensions", 0.25
    if target_count:
        for index, aggregate in enumerate(tree.find_all(exp.Count)):
            if isinstance(aggregate.this, exp.Distinct) and not intent.distinct and not intent.frequency:
                updated = tree.copy()
                list(updated.find_all(exp.Count))[index].set("this", exp.Star())
                yield updated, "count rows without deduplication", 0.3
                break
            if (isinstance(aggregate.this, exp.Column) and not intent.distinct and
                    re.search(r"count\s*\(\s*\*\s*\)", " ".join(intent.labels), re.I)):
                updated = tree.copy()
                list(updated.find_all(exp.Count))[index].set("this", exp.Star())
                yield updated, "count all rows", 0.3
                break


def predicate_literals(tree):
    for predicate in tree.find_all(exp.EQ, exp.NEQ, exp.Like):
        if isinstance(predicate.this, exp.Column) and isinstance(predicate.expression, exp.Literal):
            if predicate.expression.is_string:
                yield predicate


def question_literal_edits(tree, intent):
    for predicate in list(predicate_literals(tree))[:5]:
        literal = predicate.expression.this
        pattern = r"(?<!\w)" + re.escape(literal.strip("%_")) + r"(?!\w)"
        if not literal.strip("%_") or not re.search(pattern, intent.question, re.I):
            continue
        if literal.startswith("%") and literal.endswith("%"):
            revised = tree.copy()
            for other in predicate_literals(revised):
                if other == predicate:
                    other.replace(exp.EQ(this=other.this.copy(),
                                         expression=exp.Literal.string(literal.strip("%"))))
                    break
            yield revised, "use exact text comparison", 0.15
        if not isinstance(predicate, (exp.EQ, exp.NEQ)):
            continue
        labels = sorted(words(predicate.this.name) & intent.terms, key=lambda token: (-len(token), token))
        if labels:
            context = re.search(r"\b" + re.escape(labels[0]) + r"[ -]+" +
                                re.escape(literal) + r"(?!\w)", intent.raw_question, re.I)
            if context and context[0].casefold() not in intent.literals:
                revised = tree.copy()
                for other in predicate_literals(revised):
                    if other == predicate:
                        other.set("expression", exp.Literal.string(context[0]))
                        break
                yield revised, "use the complete name from the question", 0.45
        if literal:
            revised = tree.copy()
            for other in predicate_literals(revised):
                if other == predicate:
                    other.set("this", exp.Collate(this=other.this.copy(),
                                                  expression=exp.var("NOCASE")))
                    break
            yield revised, "compare text without case differences", 0.1


SMALL_NUMBERS = dict(zip(("one", "two", "three", "four", "five",
                          "six", "seven", "eight", "nine", "ten"), range(1, 11)))


def single_table_edits(schema, intent):
    threshold = re.search(r"\b(at least|at most|more than|fewer than|exactly) (\w+) ([a-z]+)", intent.question)
    plain_listing = re.search(r"\b(list|show|find|return|display) (?:me )?.*\ball\b", intent.question)
    if ((not threshold and not plain_listing) or intent.ordered or intent.count
            or not intent.labels or not all(re.fullmatch(r"[\w ]+", label) for label in intent.labels)):
        return
    requested = {label.casefold() for label in intent.labels}
    for relation, columns in schema.columns.items():
        if not requested <= columns.keys():
            continue
        table = schema.tables[relation]["name"]
        terms = relation_terms(table)
        if not terms or not terms <= intent.terms:
            continue
        selected = [exp.column(columns[label.casefold()], quoted=True) for label in intent.labels]
        source = exp.Table(this=exp.to_identifier(table, quoted=True))
        revised = exp.select(*selected).from_(source)
        if threshold and stem(threshold[3]) in terms:
            amount = threshold[2]
            number = int(amount) if amount.isdecimal() and len(amount) <= 4 else SMALL_NUMBERS.get(amount)
            if number is None or not 0 < number <= 1000:
                continue
            operator = {"at least": exp.GTE, "at most": exp.LTE, "more than": exp.GT,
                        "fewer than": exp.LT, "exactly": exp.EQ}[threshold[1]]
            revised.group_by(*[column.copy() for column in selected], copy=False)
            revised.having(operator(this=exp.Count(this=exp.Star()),
                                    expression=exp.Literal.number(number)), copy=False)
            yield revised, "group and count the named entities", 0.6
        elif plain_listing and not threshold and not intent.literals and not intent.numbers:
            if intent.distinct:
                revised.distinct(copy=False)
            yield revised, "list the named relation with the requested projection", 0.25


def conjunctions(node):
    if isinstance(node, exp.And):
        return [*conjunctions(node.this), *conjunctions(node.expression)]
    return [node]


def broadening_edits(tree, intent):
    where = tree.args.get("where")
    if not where:
        return
    conditions = conjunctions(where.this)
    for index, predicate in enumerate(conditions):
        if not isinstance(predicate, (exp.EQ, exp.Like)):
            continue
        literal = predicate.expression
        if not isinstance(literal, exp.Literal) or not literal.is_string:
            continue
        tokens = words(literal.this)
        if not tokens or {stem(token) for token in tokens} <= intent.terms:
            continue
        if len(conditions) == 1 and not re.search(r"\ball\b", intent.question):
            continue
        remaining = [term.copy() for offset, term in enumerate(conditions) if offset != index]
        updated = tree.copy()
        updated.set("where", exp.Where(this=exp.and_(*remaining)) if remaining else None)
        yield updated, "remove a text condition unsupported by the question", 0.2


def anti_join_edits(tree, intent):
    if not re.search(r"\b(never|without|not (?:living|have|having|participat\w*|broadcast\w*))\b",
                     intent.question):
        return
    joins = tree.args.get("joins", [])
    where = tree.args.get("where")
    if not 1 <= len(joins) <= 3 or not where or tree.args.get("with"):
        return
    if any(not isinstance(join.this, exp.Table) or not join.args.get("on") for join in joins):
        return
    first = joins[0]
    on = first.args.get("on")
    aliases = {join.this.alias_or_name.casefold() for join in joins}
    if len(aliases) != len(joins):
        return
    conditions = conjunctions(where.this)
    negated = [term for term in conditions if
               isinstance(term, exp.NEQ) or isinstance(term, exp.Not) and isinstance(term.this, (exp.In, exp.Like))]
    inner = [term for term in negated if
             all(col.table.casefold() in aliases for col in term.find_all(exp.Column))]
    if len(inner) != 1:
        return
    predicate = inner[0]
    touched = [column for column in tree.find_all(exp.Column)
               if column.table.casefold() in aliases and column.find_ancestor(exp.Join) is None
               and column is not predicate.this and column.find_ancestor(exp.Where) is not where]
    if touched:
        return
    outside = [term.copy() for term in conditions if term is not predicate]
    if any(col.table.casefold() in aliases for term in outside for col in term.find_all(exp.Column)):
        return
    positive = (exp.EQ(this=predicate.this.copy(), expression=predicate.expression.copy())
                if isinstance(predicate, exp.NEQ) else predicate.this.copy())
    if any(not column.table for column in tree.find_all(exp.Column)) and len(joins) > 1:
        return
    subquery = exp.select("1").from_(first.this.copy()).where(on.copy(), positive)
    inner_joins = [join.copy() for join in joins[1:]]
    for joined in inner_joins:
        joined.set("side", None)
        joined.set("kind", None)
    if inner_joins:
        subquery.set("joins", inner_joins)
    revised = tree.copy()
    revised.set("joins", None)
    revised.set("where", exp.Where(this=exp.and_(*outside, exp.Not(this=exp.Exists(this=subquery)))))
    yield revised, "exclude entities with a matching related row", 0.65


def foreign_key_edits(tree, schema):
    sources = {alias.casefold(): (alias, table) for alias, table in schema.sources(tree).items()}
    joins = tree.args.get("joins", [])
    for index, join in enumerate(joins):
        on = join.args.get("on")
        if not isinstance(on, exp.EQ) or not isinstance(join.this, exp.Table):
            continue
        left, right = on.this, on.expression
        if not isinstance(left, exp.Column) or not isinstance(right, exp.Column):
            continue
        alias = join.this.alias_or_name.casefold()
        if alias not in sources:
            continue
        previous = {name.casefold() for name in sources
                    if name not in {item.this.alias_or_name.casefold() for item in joins[index:]}}
        candidates = []
        right_alias, right_table = sources[alias]
        for name in sorted(previous):
            lhs_alias, lhs_table = sources[name]
            for a, b in schema.links(lhs_table, right_table):
                if (name_key(lhs_alias + a), name_key(right_alias + b)) in {
                    (name_key(left.table + left.name), name_key(right.table + right.name)),
                    (name_key(right.table + right.name), name_key(left.table + left.name))
                }:
                    candidates = []
                    break
                candidates.append((lhs_alias, a, right_alias, b))
            else:
                continue
            break
        for lhs, a, rhs, b in candidates[:2]:
            updated = tree.copy()
            updated.args["joins"][index].set("on", exp.EQ(
                this=exp.column(a, table=lhs, quoted=True),
                expression=exp.column(b, table=rhs, quoted=True)))
            yield updated, "align join predicate to a declared foreign key", 0.4


def order_through_foreign_key(tree, schema, intent):
    order = tree.args.get("order")
    first = order.expressions[0]
    if not isinstance(first, exp.Ordered) or not isinstance(first.this, exp.Column):
        return
    column = first.this
    candidates = schema.sources(tree)
    for alias, table in candidates.items():
        if column.table and alias.casefold() != column.table.casefold():
            continue
        if column.name.casefold() not in schema.columns[table]:
            continue
        for target, metadata in schema.tables.items():
            for lhs, rhs in schema.links(table, target):
                if lhs.casefold() != column.name.casefold() or target in candidates.values():
                    continue
                textual = [item["name"] for item in metadata["columns"]
                           if re.search(r"CHAR|TEXT|CLOB", item["type"], re.I)]
                textual.sort(key=lambda name: (-len({stem(x) for x in words(name)} & intent.terms), name))
                for name in textual[:2]:
                    joined = exp.Table(this=exp.to_identifier(metadata["name"], quoted=True))
                    revised = tree.join(joined, on=exp.EQ(
                        this=exp.column(lhs, table=alias, quoted=True),
                        expression=exp.column(rhs, table=metadata["name"], quoted=True)))
                    revised.args["order"].expressions[0].set(
                        "this", exp.column(name, table=metadata["name"], quoted=True))
                    yield revised, "order by the linked text field", 0.3


def join_integrity(tree, schema):
    if not isinstance(tree, exp.Select):
        return (0, 0, 0)
    sources = {alias.casefold(): table for alias, table in schema.sources(tree).items()}
    declared = questionable = tautologies = 0
    for join in tree.args.get("joins", []):
        on = join.args.get("on")
        if not on:
            continue
        for equal in on.find_all(exp.EQ):
            left, right = equal.this, equal.expression
            if not isinstance(left, exp.Column) or not isinstance(right, exp.Column):
                continue
            if not left.table or not right.table:
                continue
            if left.table.casefold() == right.table.casefold():
                tautologies += 1
                continue
            lhs, rhs = sources.get(left.table.casefold()), sources.get(right.table.casefold())
            if lhs is None or rhs is None:
                continue
            links = [(a.casefold(), b.casefold()) for a, b in schema.links(lhs, rhs)
                     if a and b]
            if (left.name.casefold(), right.name.casefold()) in links:
                declared += 1
            elif name_key(left.name) != name_key(right.name):
                questionable += 1
    return declared, questionable, tautologies


def prune_joins(tree, schema, intent):
    joins = tree.args.get("joins", [])
    if not joins or tree.args.get("with"):
        return
    sources = schema.sources(tree)
    for index, join in enumerate(joins):
        on = join.args.get("on")
        if not isinstance(join.this, exp.Table) or not isinstance(on, exp.EQ):
            continue
        alias = join.this.alias_or_name.casefold()
        target = sources.get(join.this.alias_or_name)
        if target is None:
            continue
        terms = relation_terms(schema.tables[target]["name"])
        if terms and terms <= intent.terms:
            continue
        columns = [col for col in tree.find_all(exp.Column)
                   if col.table.casefold() == alias and col.find_ancestor(exp.Select) is tree]
        if any(col.find_ancestor(exp.Join) is not join for col in columns):
            continue
        if any(not col.table and col.name.casefold() in schema.columns[target]
               for col in tree.find_all(exp.Column)):
            continue
        keys = [column["name"].casefold() for column in schema.tables[target]["columns"]
                if column["pk"]]
        if len(keys) != 1 or not any(col.name.casefold() == keys[0] for col in columns):
            continue
        if any(isinstance(item.unalias(), exp.Star) for item in tree.selects):
            continue
        updated = tree.copy()
        updated.set("joins", [item for offset, item in enumerate(updated.args["joins"])
                              if offset != index])
        yield updated, "remove unused primary-key join", 0.45


def static_penalty(tree, schema):
    if not schema.tables:
        return 0.0
    penalty = 0.0
    for scope in traverse_scope(tree):
        for source in scope.sources.values():
            if isinstance(source, exp.Table) and source.name.casefold() not in schema.tables:
                penalty += 1.8
        try:
            columns = scope.columns
        except OptimizeError:
            # A parseable candidate can still declare duplicate relation aliases.
            return 4.0
        for column in columns:
            if not column.table:
                continue
            source = next((item for alias, item in scope.sources.items()
                           if alias.casefold() == column.table.casefold()), None)
            if isinstance(source, exp.Table):
                available = schema.columns.get(source.name.casefold())
                if available is not None and column.name.casefold() not in available:
                    penalty += 1.0
    return min(penalty, 4.0)

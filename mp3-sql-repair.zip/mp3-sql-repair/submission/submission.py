"""Bounded perceive–plan–act controller for the official MP3 tool protocol."""

from collections import Counter
from dataclasses import dataclass
import json
import math
from pathlib import Path

from sqlglot import exp

from sql_repair_rules import (
    Intent, Schema, expected_projection, identifier_edits, join_integrity, label_match,
    parse, result_edits, single_table_edits, sql_key, static_penalty, syntax_edits,
)
from semantic_edits import (
    aggregate_label_score, comparisons, needs_schema, question_structure_score, semantic_edits,
)
from relational_edits import (alphabetic_order_score, bridge_joins, duplicate_join_edits,
                              name_filter_alignment, relational_edits)
from literal_probe import plan_probe
from intent_patterns import intent_edits
from projection_edits import (
    group_sort_edits, link_projection, projection_owner_edits, result_column_edits,
)


@dataclass
class Candidate:
    sql: str
    tree: exp.Expression | None
    votes: int = 0
    original: bool = False
    edit: float = 0.0
    depth: int = 0
    feedback: dict | None = None


class RepairAgent:
    def __init__(self, hints=True, edits=True, semantic=True):
        self.hints = hints
        self.edits = edits
        self.semantic = semantic
        self.probe = None
        self.pool = {}

    def add(self, sql, *, original=False, hint=False, edit=0.0, depth=0):
        if not sql or len(sql.encode("utf-8")) > 16000:
            return None
        tree = parse(sql)
        if tree is None and not original:
            return None
        key = sql_key(tree) if tree is not None else sql
        candidate = self.pool.setdefault(key, Candidate(sql, tree, original=original, edit=edit, depth=depth))
        if hint:
            candidate.votes += 1
        return candidate

    def prior(self, candidate, schema, intent):
        tree = candidate.tree
        if tree is None:
            return -10.0
        score = 0.85 * math.log2(1 + candidate.votes) + 1.0 * candidate.original
        score += candidate.edit - 0.3 * candidate.depth
        if self.semantic:
            score += intent.score(tree) - static_penalty(tree, schema)
            declared, questionable, tautologies = join_integrity(tree, schema)
            score += 0.18 * declared - 0.5 * questionable - 2.5 * tautologies
            score += sum(0.35 if isinstance(pred, expected) else -1.25
                         for _, pred, expected in comparisons(tree, intent))
            score += name_filter_alignment(tree, schema, intent)
            score += alphabetic_order_score(tree, schema, intent)
            score += aggregate_label_score(tree, intent)
            score += question_structure_score(tree, intent)
        return score

    def ranking(self, candidate, schema, intent, example):
        feedback = candidate.feedback
        score = self.prior(candidate, schema, intent)
        if not feedback:
            return score
        if not feedback["ok"]:
            return score - 40.0
        if feedback["matches_example"]:
            score += 25.0
        else:
            expected = example["row_count"]
            actual = feedback["row_count"]
            score -= 4.0 + 1.2 * abs(math.log1p(expected) - math.log1p(actual))
            score -= 2.2 * abs(len(feedback["columns"]) - len(intent.labels))
            if expected and not actual:
                score -= 1.4
            if self.semantic and expected and actual and not (example["truncated"] or feedback["truncated"]):
                target = Counter(map(tuple, example["rows"]))
                produced = Counter(map(tuple, feedback["rows"]))
                score += 2.0 * sum((target & produced).values()) / max(expected, actual)
        if self.semantic:
            score += 1.6 * label_match(feedback["columns"], intent.labels)
        return score

    def expand(self, candidate, schema, intent, example):
        tree = candidate.tree
        feedback = candidate.feedback
        depth = candidate.depth + 1
        if depth > 3:
            return
        if tree is None:
            for sql, _, strength in syntax_edits(candidate.sql, feedback):
                self.add(sql, edit=strength, depth=depth)
            for revised, _, strength in single_table_edits(schema, intent):
                self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
            return
        if feedback["ok"]:
            edits = result_edits(tree, schema, intent, feedback, example)
        else:
            edits = identifier_edits(tree, schema, feedback)
        for revised, _, strength in edits:
            self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
            if (not feedback["matches_example"] and isinstance(revised, exp.Select)
                    and len(revised.selects) != len(intent.labels)):
                projected = expected_projection(revised, schema, intent.labels)
                if projected is not None:
                    self.add(projected.sql(dialect="sqlite", comments=False),
                             edit=strength + 0.35, depth=depth + 1)
        for revised, strength in bridge_joins(tree, schema):
            self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
        if not feedback["matches_example"]:
            for generator in (link_projection, group_sort_edits, projection_owner_edits):
                for revised, strength in generator(tree, schema, intent):
                    self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
        for revised, strength in intent_edits(tree, schema, intent, feedback):
            self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
        if not feedback["ok"]:
            for revised, strength in duplicate_join_edits(tree):
                self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
            return
        for revised, strength in result_column_edits(tree, intent, feedback, example):
            self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)
        for generator in (semantic_edits, relational_edits):
            for revised, strength in generator(tree, schema, intent, feedback):
                self.add(revised.sql(dialect="sqlite", comments=False), edit=strength, depth=depth)

    def act(self, observation):
        draft = observation["issue_sql"]
        history = observation["history"]
        remaining = observation["remaining"]
        if not history:
            candidate = self.add(draft, original=True)
            if not remaining or candidate is None:
                return {"tool": "submit", "sql": draft}
            return {"tool": "check", "sql": draft}

        last = history[-1]
        used = {step["tool"] for step in history}
        if last["tool"] == "repair_hint":
            for hint in last["observation"]:
                if isinstance(hint, str):
                    self.add(hint, hint=True)
        if last["tool"] == "check":
            candidate = next(item for item in self.pool.values() if item.sql == last["sql"])
            candidate.feedback = last["observation"]

        if remaining and self.hints and "repair_hint" not in used:
            return {"tool": "repair_hint"}
        original = next(iter(self.pool.values()))
        intent = Intent.read(observation)
        if remaining > 1 and "schema" not in used and (
            len(self.pool) > 1 or (
                self.edits and (not original.feedback["matches_example"] or
                                needs_schema(original.tree, intent, original.feedback))
            )
        ):
            return {"tool": "schema"}

        schema = Schema(next((step["observation"] for step in history if step["tool"] == "schema"), []))
        example = observation["example"]
        if last["tool"] == "execute" and self.probe is not None:
            for revised in self.probe.proposals(last["observation"], intent):
                self.add(revised, depth=1, edit=1.0)
        checked = [item for item in self.pool.values() if item.feedback is not None]
        best = max(checked, key=lambda item: self.ranking(item, schema, intent, example))
        if remaining:
            if self.edits and "schema" in used:
                if last["tool"] == "schema":
                    for candidate in checked:
                        self.expand(candidate, schema, intent, example)
                elif last["tool"] == "check":
                    self.expand(candidate, schema, intent, example)
            pending = [item for item in self.pool.values() if item.feedback is None]
            if (self.edits and self.probe is None and remaining >= 2
                    and "schema" in used and not best.feedback["matches_example"]
                    and best.feedback["ok"] and (not pending or remaining == 3)):
                self.probe = plan_probe(best, schema, intent)
                if self.probe is not None:
                    return {"tool": "execute", "sql": self.probe.sql}
            if pending:
                proposed = max(pending, key=lambda item: self.prior(item, schema, intent))
                return {"tool": "check", "sql": proposed.sql}
        return {"tool": "submit", "sql": best.sql}


def create_agent(checkpoint=None):
    if checkpoint is None:
        return RepairAgent()
    path = Path(checkpoint)
    flags = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(flags, dict):
        raise ValueError("Expected a JSON settings object")
    if set(flags) - {"hints", "edits", "semantic"} or any(type(value) is not bool for value in flags.values()):
        raise ValueError("Expected boolean settings for hints, edits and semantic ranking")
    return RepairAgent(**flags)

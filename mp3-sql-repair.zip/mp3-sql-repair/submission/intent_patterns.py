"""Translate relational language cues into candidate edits."""

import re

from sqlglot import exp

from sql_repair_rules import predicate_literals, words


QUANTIFIED = re.compile(r"\bthan (?:the \w+ of )?(?:all|every|any)\b")
GROUPED_EXTREME = re.compile(r"\b(?:which|what|in what) (?:year|month|category|type|group)\b")
FEATURE_NAME = re.compile(r"(?:^is_|^has_|^can_|active|enabled|logged|login|status|visible)", re.I)
FALSE_VALUE = {"no", "false", "inactive", "disabled", "logged_out", "not_logged_in", "off"}
TRUE_VALUE = {"yes", "true", "active", "enabled", "logged_in", "on"}


def quantified_comparisons(tree, schema, intent):
    if not QUANTIFIED.search(intent.question):
        return
    operations = list(tree.find_all(exp.GT, exp.GTE, exp.LT, exp.LTE))
    for index, comparison in enumerate(operations):
        value = comparison.expression
        if not isinstance(value, (exp.All, exp.Subquery)) or not isinstance(value.this, exp.Select):
            continue
        subquery = value.this
        if len(subquery.selects) != 1 or not isinstance(subquery.selects[0], exp.Column):
            continue
        source = subquery.args.get("from")
        if not source or not isinstance(source.this, exp.Table) or subquery.args.get("joins"):
            continue
        linked = schema.columns.get(source.this.name.casefold(), {})
        higher = isinstance(comparison, (exp.GT, exp.GTE))
        every = "any" not in QUANTIFIED.search(intent.question)[0]
        extremum = exp.Max if higher == every else exp.Min
        revised = tree.copy()
        selected = list(revised.find_all(exp.GT, exp.GTE, exp.LT, exp.LTE))[index]
        query = selected.expression.this.copy()
        scope = query.args.get("where")
        if scope and not query.find(exp.Subquery):
            for predicate in predicate_literals(query):
                column = predicate.this
                if column.table and column.name.casefold() in linked:
                    column.set("table", exp.to_identifier(source.this.alias_or_name, quoted=True))
        query.select(extremum(this=query.selects[0].copy()), append=False, copy=False)
        query.set("order", None)
        query.set("limit", None)
        selected.set("expression", exp.Subquery(this=query))
        yield revised, 1.1


def grouped_extremes(tree, schema, intent):
    if (not isinstance(tree, exp.Select) or tree.args.get("group")
            or not GROUPED_EXTREME.search(intent.question)
            or intent.descending == intent.ascending):
        return
    order = tree.args.get("order")
    if not order or not tree.args.get("limit") or len(order.expressions) != 1:
        return
    key = order.expressions[0].this
    projected = [item.unalias() for item in tree.selects]
    if not isinstance(key, exp.Column) or not projected or key in projected:
        return
    if not all(isinstance(item, exp.Column) for item in projected):
        return
    available = [column["type"] for alias, table in schema.sources(tree).items()
                 if not key.table or key.table.casefold() == alias.casefold()
                 for column in schema.tables[table]["columns"]
                 if column["name"].casefold() == key.name.casefold()]
    if len(available) != 1 or not re.search(r"int|numeric|real|float|double|decimal", available[0], re.I):
        return
    updated = tree.group_by(*(item.copy() for item in projected))
    updated.args["order"].expressions[0].set("this", exp.Sum(this=key.copy()))
    yield updated, 0.8


def typed_flags(tree, schema, intent):
    if not isinstance(tree, exp.Select):
        return
    sources = schema.sources(tree)
    for index, condition in enumerate(tree.find_all(exp.EQ, exp.NEQ)):
        column, literal = condition.this, condition.expression
        if not isinstance(column, exp.Column) or not isinstance(literal, exp.Literal):
            continue
        if not literal.is_string or not FEATURE_NAME.search(column.name):
            continue
        normalized = re.sub(r"\s+", "_", literal.this.casefold().strip())
        if normalized in intent.literals or normalized not in TRUE_VALUE | FALSE_VALUE:
            continue
        types = [item["type"] for alias, table in sources.items()
                 if not column.table or column.table.casefold() == alias.casefold()
                 for item in schema.tables[table]["columns"]
                 if item["name"].casefold() == column.name.casefold()]
        if len(types) != 1 or not re.search(r"INT|BOOL", types[0], re.I):
            continue
        revised = tree.copy()
        condition = list(revised.find_all(exp.EQ, exp.NEQ))[index]
        condition.set("expression", exp.Literal.number(int(normalized in TRUE_VALUE)))
        yield revised, 0.85


def route_edits(tree, schema, intent):
    if not isinstance(tree, exp.Select) or tree.args.get("joins"):
        return
    route = re.search(r"\bfrom ([\w '-]{2,50}?) to ([\w '-]{2,50}?)(?:[?.!,]|$)", intent.raw_question, re.I)
    if not route:
        return
    start, stop = (value.strip(" '\n") for value in route.groups())
    if not start or not stop:
        return
    for alias, table in schema.sources(tree).items():
        columns = schema.columns[table]
        origins = [col for col in columns if {"origin", "departure", "source"} & words(col)]
        destinations = [col for col in columns if {"destination", "arrival"} & words(col)]
        if len(origins) != 1 or len(destinations) != 1:
            continue
        origin, destination = origins[0], destinations[0]
        predicates = [exp.EQ(this=exp.column(columns[key], table=alias, quoted=True),
                             expression=exp.Literal.string(value))
                      for key, value in ((origin, start), (destination, stop))]
        yield tree.where(*predicates, append=False), 0.95


def intent_edits(tree, schema, intent, feedback):
    yield from quantified_comparisons(tree, schema, intent)
    yield from grouped_extremes(tree, schema, intent)
    yield from ranked_count_edits(tree, intent)
    if not feedback["matches_example"]:
        yield from typed_flags(tree, schema, intent)
        yield from route_edits(tree, schema, intent)


def ranked_count_edits(tree, intent):
    if not isinstance(tree, exp.Select) or not tree.args.get("group") or intent.sorted:
        return
    phrase = re.search(r"\b(most|least|fewest|largest|highest|smallest|greatest|lowest) (?:total )?number\b",
                       intent.question)
    if not phrase or not tree.selects:
        return
    order = tree.args.get("order")
    if order and order.find(exp.Count) and tree.args.get("limit"):
        return
    direction = phrase[1] in {"most", "largest", "highest", "greatest"}
    count = exp.Count(this=exp.Star())
    ordered = exp.Ordered(this=count, desc=direction, nulls_first=not direction)
    revised = tree.order_by(ordered, append=False)
    if not revised.args.get("limit"):
        revised.limit(1, copy=False)
    having = revised.args.get("having")
    if having and having.find(exp.Subquery) and having.find(exp.Count):
        revised.set("having", None)
    yield revised, 0.95
